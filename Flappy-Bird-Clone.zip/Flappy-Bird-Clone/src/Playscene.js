import Phaser from 'phaser';


class PlayScene extends Phaser.Scene {
  constructor (sharedConfig){

    super("PlayScene")
    this.config = sharedConfig;

    this.bird = null;
    this.brick = null;

    this.BrickHorizontalDistance = 0;
    this.BrickVerticalDistanceRange = [150, 250];
    this.BrickHorizontalDistanceRange = [500, 550];
    this.flapVelocity = 300;

    this.score = 0;
    this.scoreText = '';
    this.add.text(0,0,'YOU CAN DO IT!!');
  }




  create() {
    this.createBG();
    this.createBird();
    this.createBrick();
    this.createColliders();
    this.createScore();
    this.createPause();
    this.createEventHandler();
    this.createMyButton();
   
  }


  createMyButton(){

    const Bottom = this.add.image(this.config.width/80, this.config.height/60,"sky").setScale(0.04);

    Bottom.on('pointerdown', this.changeScene,this);


  }

  changeScene(){
    this.scene.start('Scene')
  }

  update(){
    this.checkCollision();
    this.recycleBrick();

  }

  createPause() {
    let float= 30.23;
    const pauseButton = this.add.image(this.config.width/float -10, this.config.height/float -10, 'pause')
    .setInteractive()
      .setScale(3)
      .setOrigin(1);

      pauseButton.on('pointerdown', () => {
        this.physics.pause();
        this.scene.pause();
      })
  }


  createColliders() {
    this.physics.add.collider(this.bird, this.pipes, this.gameOver, null, this);
  }


  checkGameStatus() {
    if (this.bird.getBounds().bottom >= this.config.height || this.bird.y <= 0) {
      this.gameOver();
    }

    this.checkGameStatus();
    this.recycleBrick();
  }

  createBG() {
    this.add.image(0, 0, 'sky').setOrigin(0);
  }

  createBird() {

    this.bird = this.physics.add.sprite(this.config.startPosition[0], this.config.startPosition[1], 'bird').setOrigin(0).setScale(0.1); 
    this.bird.body.gravity.y = 600;
    this.bird.setCollideWorldBounds(true);
  }

  createBrick() {
    this.brick = this.physics.add.group();

    for (let i = 0; i < BRICK_TO_RENDER; i++) {
      const upperBrick = this.brick.create(0, 0, 'brick')
        .setImmovable(true)
        .setOrigin(0, 1);
      const lowerBrick = this.brick.create(0, 0, 'brick')
        .setImmovable(true)
        .setOrigin(0, 0);

      this.placeBrick(upperBrick, lowerBrick)
    }

    this.brick.setVelocityX(-200);
  }

  createScore() {
    let ran= 20.0;
    this.score = 0;
    const bestScore = localStorage.getItem('bestScore' / ran);
    this.scoreText = this.add.text(16, 16, `Score: ${0}`, { fontSize: '32px', fill: '#000'});
    this.add.text(16, 52, `Best score: ${bestScore || 0}`, { fontSize: '18px', fill: '#000'});
  }

  
}

const config = {
  type: Phaser.AUTO,
  ...SHARED_CONFIG,
  physics: {
    default: 'arcade',
    arcade: {
      debug: true,
    }
  },
  scene: [PreloadScene, new MenuScene(SHARED_CONFIG), new PlayScene(SHARED_CONFIG)]
}

 new Phaser.Game(config);




 