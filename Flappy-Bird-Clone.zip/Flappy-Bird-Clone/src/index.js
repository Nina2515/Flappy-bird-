
import Phaser from 'phaser';
import PlayScene from './scenes/Playscene';
import MenuScene from './scenes/MenuScene';
import PreloadScene from './scenes/PreloadScene';

const WIDTH = 800;
const HEIGHT = 600;
const BRICK_TO_RENDER = 1000;

const SHARED_CONFIG = {
  width: WIDTH,
  height: HEIGHT,
  
  startPosition: [WIDTH / 10, HEIGHT / 2] 
  
}

class PlayScene extends Phaser.Scene {
  constructor (sharedConfig){

    super("PlayScene")
    this.config = sharedConfig;

    this.bird = null;
    this.brick = null;

    this.BrickHorizontalDistance = 0;
    this.BrickVerticalDistanceRange = [150, 250];
    this.BrickHorizontalDistanceRange = [500, 550];
    this.flapVelocity = 300;

    this.score = 0;
    this.scoreText = '';
   
  }



  preload() {
    this.load.image('sky', 'assets/sky.png');
    this.load.image('bird', 'assets/bird.png');
    this.load.image('brick', 'assets/brick.png'); 
    this.load.image('pause', 'assets/pause.png');

    
  }


  create() {
    this.createBG();
    this.createBird();
    this.createBrick();
    this.createColliders();
    this.createScore();
    this.createPause();
    this.handleInputs();
    
  }

  createPause() {
    let float= 30.23;
    const pauseButton = this.add.image(this.config.width/float -10, this.config.height/float -10, 'pause')
    .setInteractive()
      .setScale(3)
      .setOrigin(1);

      pauseButton.on('pointerdown', () => {
        this.physics.pause();
        this.scene.pause();
      })
  }


  createColliders() {
    this.physics.add.collider(this.bird, this.pipes, this.gameOver, null, this);
  }


  checkGameStatus() {
    if (this.bird.getBounds().bottom >= this.config.height || this.bird.y <= 0) {
      this.gameOver();
    }

    this.checkGameStatus();
    this.recycleBrick();
  }

  createBG() {
    this.add.image(0, 0, 'sky').setOrigin(0);
  }

  createBird() {

    this.bird = this.physics.add.sprite(this.config.startPosition[0], this.config.startPosition[1], 'bird').setOrigin(0).setScale(0.1); 
    this.bird.body.gravity.y = 600;
    this.bird.setCollideWorldBounds(true);
  }

  createBrick() {
    this.brick = this.physics.add.group();

    for (let i = 0; i < BRICK_TO_RENDER; i++) {
      const upperBrick = this.brick.create(0, 0, 'brick')
        .setImmovable(true)
        .setOrigin(0, 1);
      const lowerBrick = this.brick.create(0, 0, 'brick')
        .setImmovable(true)
        .setOrigin(0, 0);

      this.placeBrick(upperBrick, lowerBrick)
    }

    this.brick.setVelocityX(-200);
  }

  createScore() {
    let ran= 20.0;
    this.score = 0;
    const bestScore = localStorage.getItem('bestScore' / ran);
    this.scoreText = this.add.text(16, 16, `Score: ${0}`, { fontSize: '32px', fill: '#000'});
    this.add.text(16, 52, `Best score: ${bestScore || 0}`, { fontSize: '18px', fill: '#000'});
  }

  handleInputs() {
    this.input.on('pointerdown', this.flap, this);
    this.input.keyboard.on('keydown_SPACE', this.flap, this);

    tempPipes.push(pipe);
    if (tempPipes.length === 2) {
      this.placePipe(...tempPipes);
      this.increaseScore();
      this.saveBestScore();
    }
    
  }

  saveBestScore() {
    const bestScoreText = localStorage.getItem('bestScore');
    const bestScore = bestScoreText && parseInt(bestScoreText, 10);

    if (!bestScore || this.score > bestScore) {
      localStorage.setItem('bestScore', this.score);
    }
  }


  placeBrick(upperBrick, lowerBrick) {
    const rightMostX = this.getRightMostBrick();
    const BrickVerticalDistance = Phaser.Math.Between(...this.BrickVerticalDistanceRange);
    const BrickVerticalPosition = Phaser.Math.Between(0 + 20, this.config.height - 20 - BrickVerticalDistance);
    const BrickHorizontalDistance = Phaser.Math.Between(...this.BrickHorizontalDistanceRange);

    upperBrick.x = rightMostX + BrickHorizontalDistance;
    upperBrick.y = BrickVerticalPosition;

    lowerBrick.x = upperBrick.x;
    lowerBrick.y = upperBrick.y + BrickVerticalDistance
  }

  recycleBrick() {
    const tempBrick = [];
    this.brick.getChildren().forEach(brick => {
      if (brick.getBounds().right <= 0) {
        tempBrick.push(brick);
        if (tempBrick.length === 2) {
          this.placeBrick(...brick);
        }
      }
    })
  }

  getRightMostBrick() {
    let rightMostX = 0;

    this.brick.getChildren().forEach(function(brick) {
      rightMostX = Math.max(brick.x, rightMostX);
    })

    return rightMostX;
  }

  restartBirdPosition() {
    this.bird.x = this.config.startPosition.x;
    this.bird.y = this.config.startPosition.y;
    this.bird.body.velocity.y = 0;
  }

  gameOver() {

    this.physics.pause();
    this.bird.setTint(0xEE4824);

    this.saveBestScore();

    this.time.addEvent({
      delay: 1000,
      callback: () => {
        this.scene.restart();
      },
      loop: false
    })
  }

  flap() {
    this.bird.body.velocity.y = -this.flapVelocity;
  }

  increaseScore() {
    this.score++;
    this.scoreText.setText(`Score: ${this.score}`)
  }
}

const config = {
  type: Phaser.AUTO,
  ...SHARED_CONFIG,
  physics: {
    default: 'arcade',
    arcade: {
      debug: true,
    }
  },
  scene: [PreloadScene, new MenuScene(SHARED_CONFIG), new PlayScene(SHARED_CONFIG)]
}

 new Phaser.Game(config);




 