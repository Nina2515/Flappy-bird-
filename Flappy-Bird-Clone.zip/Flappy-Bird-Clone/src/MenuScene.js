import Phaser from 'phaser';

class MenuScene extends Phaser.Scene {

  constructor() {
    super('MenuScene');
    this.config = sharedConfig;
  }

  create() {
    this.add.image(0,0,'sky').setOrigin(0,0);
    this.scene.start('playscene');
  }
}

export default MenuScene;